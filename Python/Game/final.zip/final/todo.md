TODO:
* Effects
    * particle effects (heal sparkle, smoke)
    * screen shake
    * floating combat text (hits/crits)
    * Level transition

* Gameplay
    * Civilians to rescue (if bit they turn!?)
    * items:  armor (ammo?)
    * Destructible obstacles (doors / windows)
    * more weapons
        * grenade
        * rocket

* Mob improvements
    * mob pathfinding (detect range)
    * Mob states (chasing, roaming)
